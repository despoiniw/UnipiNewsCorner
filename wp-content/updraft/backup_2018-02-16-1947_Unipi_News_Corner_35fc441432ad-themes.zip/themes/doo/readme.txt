=== Doo ===
Theme Name: Doo
Theme URI: http://themevs.com/themes/doo/
Version: 1.0.28
Requires at least: 4.5
Tested up to: 4.8
Author: ThemeVS
Author URI: http://themevs.com/
Tags: custom-background,accessibility-ready,two-columns,right-sidebar,custom-colors,custom-menu,featured-images,sticky-post,theme-options,translation-ready,blog
License: GNU General Public License v2.0
License URI: http://www.gnu.org/licenses/gpl.html

== Description ==
A beautiful two-columns WordPress theme created by the ThemeVS designers.

== License ==
- Font Awesome 4.7.0 - http://fontawesome.io
Copyright Dave Gandy
Font files licensed under SIL OFL 1.1 - http://scripts.sil.org/OFL
CSS files licensed under the MIT license - http://opensource.org/licenses/MIT

- FitVids.JS http://fitvidsjs.com FitVids.JS WTFPL license

- Photos https://pixabay.com/en/woman-laughter-happy-female-fun-1246844/ [Free-Photos][CC0 License]

- Other custom js files are our own creation and is licensed under the same license as this theme.

All other resources and theme elements are licensed under the [GNU GPL](http://www.gnu.org/licenses/old-licenses/gpl-2.0.html), version 2 or later.


Doo WordPress Theme, Copyright 2017 ThemeVS
Doo is distributed under the terms of the GNU GPL