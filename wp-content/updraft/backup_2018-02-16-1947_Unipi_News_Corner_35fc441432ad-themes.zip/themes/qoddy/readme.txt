=== Emizr Media ===
Theme Name: qoddy
Version: 1.0.0
Requires at least: 4.5
Tested up to: 4.9.2
Author: deltamadhav
Tags: custom-background,accessibility-ready,custom-colors,custom-menu,featured-images,sticky-post,theme-options,translation-ready,blog
License: GNU General Public License v2.0
License URI: http://www.gnu.org/licenses/gpl.html

== Description ==
A beautiful WordPress theme created by the Qoddy designers.

== Credits ==
* Bootstrap http://getbootstrap.com/ [MIT](http://opensource.org/licenses/MIT) Copyright 2011-2015 Twitter, Inc.

qoddy WordPress Theme is child theme of Doo WordPress Theme, Copyright 2017 ThemeVS
Doo is distributed under the terms of the GNU GPL

== License ==
- Photos https://www.pexels.com/photo/reflection-of-mountains-in-lake-during-sunset-326243/ [Free-Photos][CC0 License]

All other resources and theme elements are licensed under the [GNU GPL](http://www.gnu.org/licenses/old-licenses/gpl-2.0.html), version 2 or later.

== Changelog ==
= 1.0 =
* Initial release

= 1.0.1 =
* Added parent copyright

= 1.0.2 =
* reviewer suggest some changes

= 1.0.3 =
* custom header image implement

== Copyright ==
qoddy WordPress Theme, Copyright 2018 deltamadhav
qoddy is distributed under the terms of the GNU GPL